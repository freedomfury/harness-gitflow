from http import HTTPStatus
from typing import Any

import httpx

from ...client import AuthenticatedClient, Client
from ...models.error import Error
from ...models.failure import Failure
from ...models.get_project_list_with_multi_org_filter_module_type import (
    GetProjectListWithMultiOrgFilterModuleType,
)
from ...models.response_dto_page_response_project_response import ResponseDTOPageResponseProjectResponse
from ...models.sort_order import SortOrder
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    account_identifier: str,
    org_identifiers: list[str] | Unset = UNSET,
    has_module: bool | Unset = True,
    identifiers: list[str] | Unset = UNSET,
    module_type: GetProjectListWithMultiOrgFilterModuleType | Unset = UNSET,
    search_term: str | Unset = UNSET,
    only_favorites: bool | Unset = False,
    page_index: int | Unset = 0,
    page_size: int | Unset = 50,
    sort_orders: list[SortOrder] | Unset = UNSET,
    page_token: str | Unset = UNSET,
    with_favorites_info: bool | Unset = True,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["accountIdentifier"] = account_identifier

    json_org_identifiers: list[str] | Unset = UNSET
    if not isinstance(org_identifiers, Unset):
        json_org_identifiers = org_identifiers

    params["orgIdentifiers"] = json_org_identifiers

    params["hasModule"] = has_module

    json_identifiers: list[str] | Unset = UNSET
    if not isinstance(identifiers, Unset):
        json_identifiers = identifiers

    params["identifiers"] = json_identifiers

    json_module_type: str | Unset = UNSET
    if not isinstance(module_type, Unset):
        json_module_type = module_type

    params["moduleType"] = json_module_type

    params["searchTerm"] = search_term

    params["onlyFavorites"] = only_favorites

    params["pageIndex"] = page_index

    params["pageSize"] = page_size

    json_sort_orders: list[dict[str, Any]] | Unset = UNSET
    if not isinstance(sort_orders, Unset):
        json_sort_orders = []
        for sort_orders_item_data in sort_orders:
            sort_orders_item = sort_orders_item_data.to_dict()
            json_sort_orders.append(sort_orders_item)

    params["sortOrders"] = json_sort_orders

    params["pageToken"] = page_token

    params["withFavoritesInfo"] = with_favorites_info

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/projects/list",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Error | Failure | ResponseDTOPageResponseProjectResponse:
    if response.status_code == 400:
        response_400 = Failure.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = Error.from_dict(response.json())

        return response_404

    if response.status_code == 500:
        response_500 = Error.from_dict(response.json())

        return response_500

    response_default = ResponseDTOPageResponseProjectResponse.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Error | Failure | ResponseDTOPageResponseProjectResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    account_identifier: str,
    org_identifiers: list[str] | Unset = UNSET,
    has_module: bool | Unset = True,
    identifiers: list[str] | Unset = UNSET,
    module_type: GetProjectListWithMultiOrgFilterModuleType | Unset = UNSET,
    search_term: str | Unset = UNSET,
    only_favorites: bool | Unset = False,
    page_index: int | Unset = 0,
    page_size: int | Unset = 50,
    sort_orders: list[SortOrder] | Unset = UNSET,
    page_token: str | Unset = UNSET,
    with_favorites_info: bool | Unset = True,
) -> Response[Error | Failure | ResponseDTOPageResponseProjectResponse]:
    """List user's project with support to filter by multiple organizations

    Args:
        account_identifier (str):
        org_identifiers (list[str] | Unset):
        has_module (bool | Unset):  Default: True.
        identifiers (list[str] | Unset):
        module_type (GetProjectListWithMultiOrgFilterModuleType | Unset):
        search_term (str | Unset):
        only_favorites (bool | Unset):  Default: False.
        page_index (int | Unset):  Default: 0.
        page_size (int | Unset):  Default: 50.
        sort_orders (list[SortOrder] | Unset):
        page_token (str | Unset):
        with_favorites_info (bool | Unset):  Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | Failure | ResponseDTOPageResponseProjectResponse]
    """

    kwargs = _get_kwargs(
        account_identifier=account_identifier,
        org_identifiers=org_identifiers,
        has_module=has_module,
        identifiers=identifiers,
        module_type=module_type,
        search_term=search_term,
        only_favorites=only_favorites,
        page_index=page_index,
        page_size=page_size,
        sort_orders=sort_orders,
        page_token=page_token,
        with_favorites_info=with_favorites_info,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    account_identifier: str,
    org_identifiers: list[str] | Unset = UNSET,
    has_module: bool | Unset = True,
    identifiers: list[str] | Unset = UNSET,
    module_type: GetProjectListWithMultiOrgFilterModuleType | Unset = UNSET,
    search_term: str | Unset = UNSET,
    only_favorites: bool | Unset = False,
    page_index: int | Unset = 0,
    page_size: int | Unset = 50,
    sort_orders: list[SortOrder] | Unset = UNSET,
    page_token: str | Unset = UNSET,
    with_favorites_info: bool | Unset = True,
) -> Error | Failure | ResponseDTOPageResponseProjectResponse | None:
    """List user's project with support to filter by multiple organizations

    Args:
        account_identifier (str):
        org_identifiers (list[str] | Unset):
        has_module (bool | Unset):  Default: True.
        identifiers (list[str] | Unset):
        module_type (GetProjectListWithMultiOrgFilterModuleType | Unset):
        search_term (str | Unset):
        only_favorites (bool | Unset):  Default: False.
        page_index (int | Unset):  Default: 0.
        page_size (int | Unset):  Default: 50.
        sort_orders (list[SortOrder] | Unset):
        page_token (str | Unset):
        with_favorites_info (bool | Unset):  Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | Failure | ResponseDTOPageResponseProjectResponse
    """

    return sync_detailed(
        client=client,
        account_identifier=account_identifier,
        org_identifiers=org_identifiers,
        has_module=has_module,
        identifiers=identifiers,
        module_type=module_type,
        search_term=search_term,
        only_favorites=only_favorites,
        page_index=page_index,
        page_size=page_size,
        sort_orders=sort_orders,
        page_token=page_token,
        with_favorites_info=with_favorites_info,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    account_identifier: str,
    org_identifiers: list[str] | Unset = UNSET,
    has_module: bool | Unset = True,
    identifiers: list[str] | Unset = UNSET,
    module_type: GetProjectListWithMultiOrgFilterModuleType | Unset = UNSET,
    search_term: str | Unset = UNSET,
    only_favorites: bool | Unset = False,
    page_index: int | Unset = 0,
    page_size: int | Unset = 50,
    sort_orders: list[SortOrder] | Unset = UNSET,
    page_token: str | Unset = UNSET,
    with_favorites_info: bool | Unset = True,
) -> Response[Error | Failure | ResponseDTOPageResponseProjectResponse]:
    """List user's project with support to filter by multiple organizations

    Args:
        account_identifier (str):
        org_identifiers (list[str] | Unset):
        has_module (bool | Unset):  Default: True.
        identifiers (list[str] | Unset):
        module_type (GetProjectListWithMultiOrgFilterModuleType | Unset):
        search_term (str | Unset):
        only_favorites (bool | Unset):  Default: False.
        page_index (int | Unset):  Default: 0.
        page_size (int | Unset):  Default: 50.
        sort_orders (list[SortOrder] | Unset):
        page_token (str | Unset):
        with_favorites_info (bool | Unset):  Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | Failure | ResponseDTOPageResponseProjectResponse]
    """

    kwargs = _get_kwargs(
        account_identifier=account_identifier,
        org_identifiers=org_identifiers,
        has_module=has_module,
        identifiers=identifiers,
        module_type=module_type,
        search_term=search_term,
        only_favorites=only_favorites,
        page_index=page_index,
        page_size=page_size,
        sort_orders=sort_orders,
        page_token=page_token,
        with_favorites_info=with_favorites_info,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    account_identifier: str,
    org_identifiers: list[str] | Unset = UNSET,
    has_module: bool | Unset = True,
    identifiers: list[str] | Unset = UNSET,
    module_type: GetProjectListWithMultiOrgFilterModuleType | Unset = UNSET,
    search_term: str | Unset = UNSET,
    only_favorites: bool | Unset = False,
    page_index: int | Unset = 0,
    page_size: int | Unset = 50,
    sort_orders: list[SortOrder] | Unset = UNSET,
    page_token: str | Unset = UNSET,
    with_favorites_info: bool | Unset = True,
) -> Error | Failure | ResponseDTOPageResponseProjectResponse | None:
    """List user's project with support to filter by multiple organizations

    Args:
        account_identifier (str):
        org_identifiers (list[str] | Unset):
        has_module (bool | Unset):  Default: True.
        identifiers (list[str] | Unset):
        module_type (GetProjectListWithMultiOrgFilterModuleType | Unset):
        search_term (str | Unset):
        only_favorites (bool | Unset):  Default: False.
        page_index (int | Unset):  Default: 0.
        page_size (int | Unset):  Default: 50.
        sort_orders (list[SortOrder] | Unset):
        page_token (str | Unset):
        with_favorites_info (bool | Unset):  Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | Failure | ResponseDTOPageResponseProjectResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            account_identifier=account_identifier,
            org_identifiers=org_identifiers,
            has_module=has_module,
            identifiers=identifiers,
            module_type=module_type,
            search_term=search_term,
            only_favorites=only_favorites,
            page_index=page_index,
            page_size=page_size,
            sort_orders=sort_orders,
            page_token=page_token,
            with_favorites_info=with_favorites_info,
        )
    ).parsed
