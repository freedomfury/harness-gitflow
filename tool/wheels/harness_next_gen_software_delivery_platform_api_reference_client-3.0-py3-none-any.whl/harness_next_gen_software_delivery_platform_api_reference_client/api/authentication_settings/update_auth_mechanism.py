from http import HTTPStatus
from typing import Any

import httpx

from ...client import AuthenticatedClient, Client
from ...models.error import Error
from ...models.failure import Failure
from ...models.rest_response_boolean import RestResponseBoolean
from ...models.update_auth_mechanism_authentication_mechanism import (
    UpdateAuthMechanismAuthenticationMechanism,
)
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    account_identifier: str,
    authentication_mechanism: UpdateAuthMechanismAuthenticationMechanism | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["accountIdentifier"] = account_identifier

    json_authentication_mechanism: str | Unset = UNSET
    if not isinstance(authentication_mechanism, Unset):
        json_authentication_mechanism = authentication_mechanism

    params["authenticationMechanism"] = json_authentication_mechanism

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/authentication-settings/update-auth-mechanism",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Error | Failure | RestResponseBoolean:
    if response.status_code == 400:
        response_400 = Failure.from_dict(response.json())

        return response_400

    if response.status_code == 500:
        response_500 = Error.from_dict(response.json())

        return response_500

    response_default = RestResponseBoolean.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Error | Failure | RestResponseBoolean]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    account_identifier: str,
    authentication_mechanism: UpdateAuthMechanismAuthenticationMechanism | Unset = UNSET,
) -> Response[Error | Failure | RestResponseBoolean]:
    """Update Auth mechanism

     Updates the authentication mechanism for the given Account ID.

    Args:
        account_identifier (str):
        authentication_mechanism (UpdateAuthMechanismAuthenticationMechanism | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | Failure | RestResponseBoolean]
    """

    kwargs = _get_kwargs(
        account_identifier=account_identifier,
        authentication_mechanism=authentication_mechanism,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    account_identifier: str,
    authentication_mechanism: UpdateAuthMechanismAuthenticationMechanism | Unset = UNSET,
) -> Error | Failure | RestResponseBoolean | None:
    """Update Auth mechanism

     Updates the authentication mechanism for the given Account ID.

    Args:
        account_identifier (str):
        authentication_mechanism (UpdateAuthMechanismAuthenticationMechanism | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | Failure | RestResponseBoolean
    """

    return sync_detailed(
        client=client,
        account_identifier=account_identifier,
        authentication_mechanism=authentication_mechanism,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    account_identifier: str,
    authentication_mechanism: UpdateAuthMechanismAuthenticationMechanism | Unset = UNSET,
) -> Response[Error | Failure | RestResponseBoolean]:
    """Update Auth mechanism

     Updates the authentication mechanism for the given Account ID.

    Args:
        account_identifier (str):
        authentication_mechanism (UpdateAuthMechanismAuthenticationMechanism | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | Failure | RestResponseBoolean]
    """

    kwargs = _get_kwargs(
        account_identifier=account_identifier,
        authentication_mechanism=authentication_mechanism,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    account_identifier: str,
    authentication_mechanism: UpdateAuthMechanismAuthenticationMechanism | Unset = UNSET,
) -> Error | Failure | RestResponseBoolean | None:
    """Update Auth mechanism

     Updates the authentication mechanism for the given Account ID.

    Args:
        account_identifier (str):
        authentication_mechanism (UpdateAuthMechanismAuthenticationMechanism | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | Failure | RestResponseBoolean
    """

    return (
        await asyncio_detailed(
            client=client,
            account_identifier=account_identifier,
            authentication_mechanism=authentication_mechanism,
        )
    ).parsed
